﻿Public Class frmEMII
    Dim serialdelay As Integer

    Private Sub tmrRx_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrRx.Tick
        Dim rxstring As String
        Dim RX() As String
        Dim temp() As String
        'Timer2.Enabled = False
        If SerialPort1.BytesToRead > 1 Then
            serialdelay = serialdelay + 1
            If serialdelay > 3 Then
                rxstring = SerialPort1.ReadExisting
                rxstring = rxstring.Replace(Chr(13), Chr(13) + Chr(10))
                serialdelay = 0

                RX = rxstring.Split(",")

                'OK must be the first in splitted string
                If RX(0) <> Chr(2) + "OK" Then
                    lblAlarm.BackColor = Color.Red
                    Exit Sub
                End If

                lblAlarm.BackColor = Color.Black

                lblVer.Text = RX(1)

                temp = RX(2).Split(".")
                lblVRMS.Text = temp(0)
                lblVrms1.Text = temp(1)

                temp = RX(3).Split(".")
                lblIrms.Text = temp(0)
                lblIrms1.Text = temp(1)

                temp = RX(4).Split(".")
                lblRP.Text = temp(0)
                lblRP1.Text = temp(1)

                temp = RX(8).Split(".")
                lblPF.Text = temp(0)
                lblPF1.Text = temp(1)

                lblS.Text = RX(5)
                lblQ.Text = RX(6)

                lblF.Text = RX(11)
                lblH.Text = RX(10)
                lblFQ.Text = RX(12)

                lblWHr.Text = RX(13)
                lblIT.Text = Sec2Time(Val(RX(14)))
                lblTemp.Text = RX(9)



            End If

        Else
            serialdelay = 0
        End If
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        SerialPort1.Open()

    End Sub

    Private Sub InitMeterToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles InitMeterToolStripMenuItem.Click
        SerialPort1.Write(Chr(2) + "M2" + Chr(3))
    End Sub

    Private Function Sec2Time(ByVal Time As Integer)
        Dim sec, min, hr As Integer
        Dim s, m, h As String

        hr = Int(Time / 3600)
        min = Int((Time - Int(hr * 3600)) / 60)
        sec = Time - Int(hr * 3600) - Int(min * 60)
        s = sec.ToString
        m = min.ToString
        h = hr.ToString

        If s.Length < 2 Then s = "0" + s
        If m.Length < 2 Then m = "0" + m
        If h.Length < 2 Then h = "0" + h

        Return (h + ":" + m + ":" + s)



    End Function

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        SerialPort1.Write(Chr(2) + "R" + Chr(3))
    End Sub

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click
        SerialPort1.Close()
        End
    End Sub

    Private Sub OFFSETCalToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OFFSETCalToolStripMenuItem.Click
        If MsgBox("Calibrate Offset. Are you sure?", MsgBoxStyle.YesNo) = MsgBoxResult.No Then Exit Sub

        If MsgBox("Remove ACV jumper and press OK..", MsgBoxStyle.OkCancel) = MsgBoxResult.Cancel Then Exit Sub

        tmrRx.Enabled = False
        SerialPort1.ReadExisting()  'clear buffer
        SerialPort1.Write(Chr(2) + "O" + Chr(3))

        Do
            Application.DoEvents()
        Loop Until SerialPort1.BytesToRead > 1

        MsgBox(SerialPort1.ReadExisting, MsgBoxStyle.OkOnly)
        tmrRx.Enabled = True

    End Sub
End Class
