﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmEMII
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.tmrRx = New System.Windows.Forms.Timer(Me.components)
        Me.SerialPort1 = New System.IO.Ports.SerialPort(Me.components)
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SetupToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.COMPORTToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.InitMeterToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.OFFSETCalToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.lblIrms1 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.lblIrms = New System.Windows.Forms.Label
        Me.lblVrms1 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.lblVRMS = New System.Windows.Forms.Label
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.lblPF1 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.lblPF = New System.Windows.Forms.Label
        Me.lblRP1 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.lblRP = New System.Windows.Forms.Label
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.lblTemp = New System.Windows.Forms.Label
        Me.Label21 = New System.Windows.Forms.Label
        Me.lblFQ = New System.Windows.Forms.Label
        Me.Label19 = New System.Windows.Forms.Label
        Me.lblH = New System.Windows.Forms.Label
        Me.Label17 = New System.Windows.Forms.Label
        Me.lblF = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.lblQ = New System.Windows.Forms.Label
        Me.Label14 = New System.Windows.Forms.Label
        Me.lblS = New System.Windows.Forms.Label
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.btnClear = New System.Windows.Forms.Button
        Me.lblIT = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.Label18 = New System.Windows.Forms.Label
        Me.lblWHr = New System.Windows.Forms.Label
        Me.lblAlarm = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.lblVer = New System.Windows.Forms.Label
        Me.MenuStrip1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.SuspendLayout()
        '
        'tmrRx
        '
        Me.tmrRx.Enabled = True
        Me.tmrRx.Interval = 200
        '
        'SerialPort1
        '
        Me.SerialPort1.RtsEnable = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.SetupToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(754, 24)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(92, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'SetupToolStripMenuItem
        '
        Me.SetupToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.COMPORTToolStripMenuItem, Me.InitMeterToolStripMenuItem, Me.OFFSETCalToolStripMenuItem})
        Me.SetupToolStripMenuItem.Name = "SetupToolStripMenuItem"
        Me.SetupToolStripMenuItem.Size = New System.Drawing.Size(49, 20)
        Me.SetupToolStripMenuItem.Text = "Setup"
        '
        'COMPORTToolStripMenuItem
        '
        Me.COMPORTToolStripMenuItem.Name = "COMPORTToolStripMenuItem"
        Me.COMPORTToolStripMenuItem.Size = New System.Drawing.Size(135, 22)
        Me.COMPORTToolStripMenuItem.Text = "COM PORT"
        '
        'InitMeterToolStripMenuItem
        '
        Me.InitMeterToolStripMenuItem.Name = "InitMeterToolStripMenuItem"
        Me.InitMeterToolStripMenuItem.Size = New System.Drawing.Size(135, 22)
        Me.InitMeterToolStripMenuItem.Text = "Init Meter"
        '
        'OFFSETCalToolStripMenuItem
        '
        Me.OFFSETCalToolStripMenuItem.Name = "OFFSETCalToolStripMenuItem"
        Me.OFFSETCalToolStripMenuItem.Size = New System.Drawing.Size(135, 22)
        Me.OFFSETCalToolStripMenuItem.Text = "OFFSET Cal"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.lblIrms1)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.lblIrms)
        Me.GroupBox1.Controls.Add(Me.lblVrms1)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.lblVRMS)
        Me.GroupBox1.Location = New System.Drawing.Point(29, 64)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(538, 125)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        '
        'lblIrms1
        '
        Me.lblIrms1.BackColor = System.Drawing.Color.Black
        Me.lblIrms1.Font = New System.Drawing.Font("7 Segment", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.lblIrms1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblIrms1.Location = New System.Drawing.Point(388, 29)
        Me.lblIrms1.Name = "lblIrms1"
        Me.lblIrms1.Size = New System.Drawing.Size(138, 72)
        Me.lblIrms1.TabIndex = 8
        Me.lblIrms1.Text = "000"
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.Black
        Me.Label5.Font = New System.Drawing.Font("Arial", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label5.Location = New System.Drawing.Point(364, 29)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(40, 72)
        Me.Label5.TabIndex = 7
        Me.Label5.Text = "."
        '
        'lblIrms
        '
        Me.lblIrms.BackColor = System.Drawing.Color.Black
        Me.lblIrms.Font = New System.Drawing.Font("7 Segment", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.lblIrms.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblIrms.Location = New System.Drawing.Point(278, 29)
        Me.lblIrms.Name = "lblIrms"
        Me.lblIrms.Size = New System.Drawing.Size(104, 72)
        Me.lblIrms.TabIndex = 6
        Me.lblIrms.Text = "00"
        Me.lblIrms.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblVrms1
        '
        Me.lblVrms1.BackColor = System.Drawing.Color.Black
        Me.lblVrms1.Font = New System.Drawing.Font("7 Segment", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.lblVrms1.ForeColor = System.Drawing.Color.Red
        Me.lblVrms1.Location = New System.Drawing.Point(153, 29)
        Me.lblVrms1.Name = "lblVrms1"
        Me.lblVrms1.Size = New System.Drawing.Size(99, 72)
        Me.lblVrms1.TabIndex = 5
        Me.lblVrms1.Text = "000"
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.Black
        Me.Label3.Font = New System.Drawing.Font("Arial", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Red
        Me.Label3.Location = New System.Drawing.Point(129, 29)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(40, 72)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "."
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(276, 101)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(69, 16)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "AMP rms"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(6, 101)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(76, 16)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "VOLT rms"
        '
        'lblVRMS
        '
        Me.lblVRMS.BackColor = System.Drawing.Color.Black
        Me.lblVRMS.Font = New System.Drawing.Font("7 Segment", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.lblVRMS.ForeColor = System.Drawing.Color.Red
        Me.lblVRMS.Location = New System.Drawing.Point(11, 29)
        Me.lblVRMS.Name = "lblVRMS"
        Me.lblVRMS.Size = New System.Drawing.Size(136, 72)
        Me.lblVRMS.TabIndex = 0
        Me.lblVRMS.Text = "000"
        Me.lblVRMS.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.lblPF1)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.lblPF)
        Me.GroupBox2.Controls.Add(Me.lblRP1)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Controls.Add(Me.lblRP)
        Me.GroupBox2.Location = New System.Drawing.Point(29, 200)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(538, 125)
        Me.GroupBox2.TabIndex = 3
        Me.GroupBox2.TabStop = False
        '
        'lblPF1
        '
        Me.lblPF1.BackColor = System.Drawing.Color.Black
        Me.lblPF1.Font = New System.Drawing.Font("7 Segment", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.lblPF1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblPF1.Location = New System.Drawing.Point(388, 29)
        Me.lblPF1.Name = "lblPF1"
        Me.lblPF1.Size = New System.Drawing.Size(123, 53)
        Me.lblPF1.TabIndex = 8
        Me.lblPF1.Text = "0000"
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.Black
        Me.Label6.Font = New System.Drawing.Font("Arial", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label6.Location = New System.Drawing.Point(370, 29)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(34, 53)
        Me.Label6.TabIndex = 7
        Me.Label6.Text = "."
        '
        'lblPF
        '
        Me.lblPF.BackColor = System.Drawing.Color.Black
        Me.lblPF.Font = New System.Drawing.Font("7 Segment", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.lblPF.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblPF.Location = New System.Drawing.Point(306, 29)
        Me.lblPF.Name = "lblPF"
        Me.lblPF.Size = New System.Drawing.Size(76, 53)
        Me.lblPF.TabIndex = 6
        Me.lblPF.Text = "00"
        Me.lblPF.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblRP1
        '
        Me.lblRP1.BackColor = System.Drawing.Color.Black
        Me.lblRP1.Font = New System.Drawing.Font("7 Segment", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.lblRP1.ForeColor = System.Drawing.Color.Lime
        Me.lblRP1.Location = New System.Drawing.Point(191, 29)
        Me.lblRP1.Name = "lblRP1"
        Me.lblRP1.Size = New System.Drawing.Size(99, 72)
        Me.lblRP1.TabIndex = 5
        Me.lblRP1.Text = "000"
        '
        'Label9
        '
        Me.Label9.BackColor = System.Drawing.Color.Black
        Me.Label9.Font = New System.Drawing.Font("Arial", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Lime
        Me.Label9.Location = New System.Drawing.Point(167, 29)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(40, 72)
        Me.Label9.TabIndex = 4
        Me.Label9.Text = "."
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(305, 85)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(99, 16)
        Me.Label10.TabIndex = 3
        Me.Label10.Text = "Power Factor"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(15, 101)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(88, 16)
        Me.Label11.TabIndex = 2
        Me.Label11.Text = "Real Power"
        '
        'lblRP
        '
        Me.lblRP.BackColor = System.Drawing.Color.Black
        Me.lblRP.Font = New System.Drawing.Font("7 Segment", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.lblRP.ForeColor = System.Drawing.Color.Lime
        Me.lblRP.Location = New System.Drawing.Point(11, 29)
        Me.lblRP.Name = "lblRP"
        Me.lblRP.Size = New System.Drawing.Size(174, 72)
        Me.lblRP.TabIndex = 0
        Me.lblRP.Text = "0000"
        Me.lblRP.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.Silver
        Me.GroupBox3.Controls.Add(Me.Label7)
        Me.GroupBox3.Controls.Add(Me.lblTemp)
        Me.GroupBox3.Controls.Add(Me.Label21)
        Me.GroupBox3.Controls.Add(Me.lblFQ)
        Me.GroupBox3.Controls.Add(Me.Label19)
        Me.GroupBox3.Controls.Add(Me.lblH)
        Me.GroupBox3.Controls.Add(Me.Label17)
        Me.GroupBox3.Controls.Add(Me.lblF)
        Me.GroupBox3.Controls.Add(Me.Label15)
        Me.GroupBox3.Controls.Add(Me.lblQ)
        Me.GroupBox3.Controls.Add(Me.Label14)
        Me.GroupBox3.Controls.Add(Me.lblS)
        Me.GroupBox3.Location = New System.Drawing.Point(573, 38)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(159, 427)
        Me.GroupBox3.TabIndex = 4
        Me.GroupBox3.TabStop = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(28, 408)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(107, 13)
        Me.Label7.TabIndex = 11
        Me.Label7.Text = "Chip Temperature (C)"
        '
        'lblTemp
        '
        Me.lblTemp.BackColor = System.Drawing.Color.Black
        Me.lblTemp.Font = New System.Drawing.Font("8Pin Matrix", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTemp.ForeColor = System.Drawing.Color.Yellow
        Me.lblTemp.Location = New System.Drawing.Point(27, 363)
        Me.lblTemp.Name = "lblTemp"
        Me.lblTemp.Size = New System.Drawing.Size(105, 36)
        Me.lblTemp.TabIndex = 10
        Me.lblTemp.Text = "00.00"
        Me.lblTemp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(3, 275)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(147, 13)
        Me.Label21.TabIndex = 9
        Me.Label21.Text = "Fundamental Reactive Power"
        '
        'lblFQ
        '
        Me.lblFQ.BackColor = System.Drawing.Color.Black
        Me.lblFQ.Font = New System.Drawing.Font("8Pin Matrix", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFQ.ForeColor = System.Drawing.Color.Fuchsia
        Me.lblFQ.Location = New System.Drawing.Point(8, 230)
        Me.lblFQ.Name = "lblFQ"
        Me.lblFQ.Size = New System.Drawing.Size(142, 36)
        Me.lblFQ.TabIndex = 8
        Me.lblFQ.Text = "0000.00"
        Me.lblFQ.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(36, 340)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(85, 13)
        Me.Label19.TabIndex = 7
        Me.Label19.Text = "Harmonic Power"
        '
        'lblH
        '
        Me.lblH.BackColor = System.Drawing.Color.Black
        Me.lblH.Font = New System.Drawing.Font("8Pin Matrix", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblH.ForeColor = System.Drawing.Color.Fuchsia
        Me.lblH.Location = New System.Drawing.Point(8, 295)
        Me.lblH.Name = "lblH"
        Me.lblH.Size = New System.Drawing.Size(142, 36)
        Me.lblH.TabIndex = 6
        Me.lblH.Text = "0000.00"
        Me.lblH.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(36, 207)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(101, 13)
        Me.Label17.TabIndex = 5
        Me.Label17.Text = "Fundamental Power"
        '
        'lblF
        '
        Me.lblF.BackColor = System.Drawing.Color.Black
        Me.lblF.Font = New System.Drawing.Font("8Pin Matrix", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblF.ForeColor = System.Drawing.Color.Fuchsia
        Me.lblF.Location = New System.Drawing.Point(8, 162)
        Me.lblF.Name = "lblF"
        Me.lblF.Size = New System.Drawing.Size(142, 36)
        Me.lblF.TabIndex = 4
        Me.lblF.Text = "0000.00"
        Me.lblF.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(36, 139)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(100, 13)
        Me.Label15.TabIndex = 3
        Me.Label15.Text = "Reactive Power (Q)"
        '
        'lblQ
        '
        Me.lblQ.BackColor = System.Drawing.Color.Black
        Me.lblQ.Font = New System.Drawing.Font("8Pin Matrix", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblQ.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblQ.Location = New System.Drawing.Point(8, 94)
        Me.lblQ.Name = "lblQ"
        Me.lblQ.Size = New System.Drawing.Size(142, 36)
        Me.lblQ.TabIndex = 2
        Me.lblQ.Text = "0000.00"
        Me.lblQ.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(36, 71)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(99, 13)
        Me.Label14.TabIndex = 1
        Me.Label14.Text = "Apparent Power (S)"
        '
        'lblS
        '
        Me.lblS.BackColor = System.Drawing.Color.Black
        Me.lblS.Font = New System.Drawing.Font("8Pin Matrix", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblS.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblS.Location = New System.Drawing.Point(8, 26)
        Me.lblS.Name = "lblS"
        Me.lblS.Size = New System.Drawing.Size(142, 36)
        Me.lblS.TabIndex = 0
        Me.lblS.Text = "0000.00"
        Me.lblS.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.btnClear)
        Me.GroupBox4.Controls.Add(Me.lblIT)
        Me.GroupBox4.Controls.Add(Me.Label16)
        Me.GroupBox4.Controls.Add(Me.Label18)
        Me.GroupBox4.Controls.Add(Me.lblWHr)
        Me.GroupBox4.Location = New System.Drawing.Point(29, 333)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(538, 125)
        Me.GroupBox4.TabIndex = 9
        Me.GroupBox4.TabStop = False
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(400, 93)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(118, 24)
        Me.btnClear.TabIndex = 9
        Me.btnClear.Text = "CLEAR"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'lblIT
        '
        Me.lblIT.BackColor = System.Drawing.Color.Black
        Me.lblIT.Font = New System.Drawing.Font("8Pin Matrix", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblIT.ForeColor = System.Drawing.Color.Yellow
        Me.lblIT.Location = New System.Drawing.Point(388, 29)
        Me.lblIT.Name = "lblIT"
        Me.lblIT.Size = New System.Drawing.Size(138, 34)
        Me.lblIT.TabIndex = 8
        Me.lblIT.Text = "12:00:00"
        Me.lblIT.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(398, 68)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(120, 16)
        Me.Label16.TabIndex = 3
        Me.Label16.Text = "Integration Time"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(15, 101)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(77, 16)
        Me.Label18.TabIndex = 2
        Me.Label18.Text = "Watt-Hour"
        '
        'lblWHr
        '
        Me.lblWHr.BackColor = System.Drawing.Color.Black
        Me.lblWHr.Font = New System.Drawing.Font("8Pin Matrix", 32.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWHr.ForeColor = System.Drawing.Color.Lime
        Me.lblWHr.Location = New System.Drawing.Point(11, 29)
        Me.lblWHr.Name = "lblWHr"
        Me.lblWHr.Size = New System.Drawing.Size(371, 72)
        Me.lblWHr.TabIndex = 0
        Me.lblWHr.Text = "000000.0000"
        Me.lblWHr.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblAlarm
        '
        Me.lblAlarm.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblAlarm.Location = New System.Drawing.Point(534, 37)
        Me.lblAlarm.Name = "lblAlarm"
        Me.lblAlarm.Size = New System.Drawing.Size(26, 24)
        Me.lblAlarm.TabIndex = 10
        Me.lblAlarm.Text = " "
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(419, 48)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(108, 13)
        Me.Label8.TabIndex = 11
        Me.Label8.Text = "ALARM/OVERLOAD"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(35, 38)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(62, 13)
        Me.Label4.TabIndex = 12
        Me.Label4.Text = "Firmware V:"
        '
        'lblVer
        '
        Me.lblVer.AutoSize = True
        Me.lblVer.Location = New System.Drawing.Point(103, 38)
        Me.lblVer.Name = "lblVer"
        Me.lblVer.Size = New System.Drawing.Size(16, 13)
        Me.lblVer.TabIndex = 13
        Me.lblVer.Text = "   "
        '
        'frmEMII
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(754, 486)
        Me.Controls.Add(Me.lblVer)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.lblAlarm)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frmEMII"
        Me.Text = "Energy Meter II Demo Program"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents tmrRx As System.Windows.Forms.Timer
    Friend WithEvents SerialPort1 As System.IO.Ports.SerialPort
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SetupToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents COMPORTToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InitMeterToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents lblVRMS As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents lblVrms1 As System.Windows.Forms.Label
    Friend WithEvents lblIrms1 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents lblIrms As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents lblPF1 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents lblPF As System.Windows.Forms.Label
    Friend WithEvents lblRP1 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents lblRP As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents lblS As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents lblQ As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents lblFQ As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents lblH As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents lblF As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents lblIT As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents lblWHr As System.Windows.Forms.Label
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents lblTemp As System.Windows.Forms.Label
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lblAlarm As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents lblVer As System.Windows.Forms.Label
    Friend WithEvents OFFSETCalToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

End Class
